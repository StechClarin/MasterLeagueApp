import {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
} from "./chunk-JUJGM2BG.js";
import "./chunk-5Q3W3A6H.js";
import "./chunk-XS73CW5H.js";
import "./chunk-SGMLAKGD.js";
import "./chunk-XT6ZCHFH.js";
import "./chunk-ZYKX7RMX.js";
import "./chunk-TXDUYLVM.js";
export {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
};
//# sourceMappingURL=@angular_core_rxjs-interop.js.map
