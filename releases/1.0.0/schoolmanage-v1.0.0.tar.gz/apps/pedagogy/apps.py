from django.apps import AppConfig


class PedagogyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.pedagogy'
